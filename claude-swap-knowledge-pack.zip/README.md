# claude-swap Drop-in

One zip. Two halves: a for-humans primer and a for-ai searchable knowledge base.

## What's inside

```
claude-swap-dropin/
  for-humans/   — read first
    claude-swap-primer.md         — top-down orientation: what it is, why, how it works
  for-ai/       — the searchable knowledge pack (wire this into your agent)
    claude-swap-kb.rvf            — single 384-dim bge-small vector DB (the "brain")
    claude-swap-kb.passages.jsonl — full passage text (13 passages; search returns TEXT, not {id,distance})
    claude-swap-kb.ids.json       — id → passage index
    claude-swap-symbols.json      — exact public API: every symbol + signature + doc + location
    claude-swap-dep-graph.json    — component dependency graph (what depends on what)
    claude-swap-entrypoints.json  — build/test/run/install commands + binaries
    ask-kb.mjs · kb-mcp-server.mjs · kb.config.mjs · resolve-deps.mjs · package.json
  README.md     — this file
  manifest.json — build metadata
```

## Studio (NotebookLM)
This is a **studio-less** build (INV-03): the searchable AI pack ships now; NotebookLM audio/report
media follow up later if produced. Nothing here depends on them.

## Three steps to wire the AI half in
```bash
# 1 — unzip + install (two deps, Node 18+)
unzip claude-swap-knowledge-pack.zip && cd claude-swap-dropin/for-ai && npm install

# 2 — ask the brain a question straight away
node ask-kb.mjs claude-swap "what does claude-swap actually do"

# 3 — point your AI host at it with a .mcp.json in your project root:
#   { "mcpServers": { "claude-swap-kb": { "command": "node", "args": ["for-ai/kb-mcp-server.mjs"] } } }
```

Built with the Repo-Primer recipe (ADR-0001 / ADR-0005). Embedder: Xenova/bge-small-en-v1.5.

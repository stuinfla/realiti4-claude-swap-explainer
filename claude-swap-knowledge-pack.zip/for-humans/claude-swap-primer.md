# claude-swap

## 1. What is claude-swap

claude-swap is a Python command-line tool for managing multiple Claude accounts. It's a multi-account switcher for Claude Code that lets you move between accounts without logging out, or have it switch accounts automatically for you before you hit a rate limit. It works with both the Claude Code CLI and the VS Code extension, and runs on macOS, Linux, and Windows.

## 2. What can it do for you

- **Manual and automatic switching** between Claude accounts, triggered either by you or by a background watcher (`cswap auto`) that monitors your 5-hour and 7-day usage windows and switches to the account with the most quota left before you hit a limit (default threshold: 90%, configurable).
- **Model-aware switching**: you can fold a specific model's quota (e.g. Fable) into the auto-switch decision, matched case-insensitively against Anthropic's per-model `display_name`.
- **Run accounts in parallel** via session mode (`cswap run`), which launches Claude Code as a specific account in the current terminal only, leaving other terminals and the VS Code extension on your default account.
- **Live usage dashboard**: an interactive full-screen TUI (`cswap` or `cswap tui`/`cswap watch`) showing live 5h/7d usage, reset times, and the active account, all keyboard-driven.
- **Scripting support**: `--json` output on `list`, `status`, and `switch` for machine-readable automation, plus exit codes on `cswap auto --once` (0 switched, 1 error, 2 nothing to do, 3 blocked) for cron/systemd use.
- **Cross-machine usage sharing** (`import-usage`) so machines sharing the same accounts/login don't double-count usage-endpoint polling.
- **Flexible account onboarding**: add accounts via browser login, from a raw setup-token or managed API key (`cswap add-token`), or to a specific slot.
- **Optional macOS menu bar app** showing 5h/7d/spend usage with click-to-switch, sharing the same auto-switch engine as `cswap auto`.

## 3. What is it made of (the components)

The repo is indexed as a single Python component, **claude-swap**, with no internal sub-components and no public API symbols exposed — it's built and consumed as a CLI tool, not a library. It has no internal dependencies within the repo.

External dependencies include a TUI framework (`textual`), `truststore` (for certificate handling), and `win32` bindings (for Windows-specific credential handling). An optional `menubar` extra adds macOS menu bar support.

## 4. How it works

- When you add an account, claude-swap backs up its OAuth tokens and config.
- On switch, it swaps only the account-specific Claude login; account-independent OAuth state (like MCP server logins) is preserved rather than overwritten by an older slot snapshot.
- Account credentials are stored using platform-appropriate secure methods — a file on Linux/Windows (which Claude Code re-reads on change, so switches take effect on the next message with no restart) and the macOS Keychain (which Claude Code caches for about 30 seconds).
- Both manual and automatic switches hold Claude Code's own credential locks while writing, so a swap never interleaves with a token refresh.
- The auto-switcher refreshes a target account's token before activating it, and quarantines accounts whose refresh fails.

## 5. How do I install and use it

Install with uv (recommended):

```bash
uv tool install claude-swap
# with the optional macOS menu bar extra:
uv tool install 'claude-swap[menubar]'
```

From source:

```bash
uv sync
uv run cswap help
```

Other useful commands: `uv tool upgrade claude-swap` to update, `uv tool uninstall claude-swap` to remove.

Quickstart:

```bash
uv run cswap help
```

From there, common entry points are `cswap` (launch the TUI), `cswap add` (add/refresh an account), `cswap list`, `cswap switch`, `cswap run`, and `cswap auto`.

## 6. Honest scope and limits

The knowledge base behind this primer covers 13 passages and documents 0 public symbols — claude-swap is meant to be used as an installed CLI tool, not imported as a library, so there isn't a programmatic API surface to describe. There are no internal component dependencies to speak of (it's a single, self-contained tool), and the external dependency list here is limited to what's indexed (`textual`, `truststore`, `win32`, and an `s` entry of unclear origin from the indexed metadata) — treat this as a partial view, not a full dependency manifest. The menu bar app is explicitly macOS-only and requires an extra install step.
